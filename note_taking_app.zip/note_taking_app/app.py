from flask import Flask, render_template, request,session,redirect,url_for
from flask_session import Session

app = Flask(__name__)


notes = []
@app.route('/', methods=["GET","POST"])
def index():
   if request.method == "POST":
    note = request.form.get("note")
    if note != "": 
        notes.append(note)
        
   elif request.method == "GET":
        note_to_remove = request.args.get("remove_note")
        if note_to_remove is not None and note_to_remove in notes:
            notes.remove(note_to_remove)
        else:
            notes.clear()

   return render_template("home.html", notes=notes)


if __name__ == '__main__':
    app.run(debug=True)